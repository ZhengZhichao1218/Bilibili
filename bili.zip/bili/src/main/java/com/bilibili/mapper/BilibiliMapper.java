package com.bilibili.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import com.bilibili.bean.Point;

import java.util.List;

public interface BilibiliMapper {
    @Select({
            "select",
            "id,title,bfl,dml,up,score,url",
            "from bili_202101"
    })
    List<Point> selectAll();

    @Select({
            "${sql}"//不是数据库里的属性用$  是就用#
    })
    int selectNumBySql(@Param("sql") String sql);
}
