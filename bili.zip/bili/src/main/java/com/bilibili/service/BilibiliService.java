package com.bilibili.service;

import java.util.List;
import com.bilibili.bean.Point;

public interface BilibiliService {
    public List<Point> selectAll();
    public int selectNumBySql(String sql);
}
