package com.bilibili.service;

import com.bilibili.bean.Point;
import com.bilibili.mapper.BilibiliMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("BilibiliService")
public class BilibiliServiceImpl implements BilibiliService {
    @Resource
    private BilibiliMapper bilibiliMapper;

    @Override
    public List<Point> selectAll(){ return bilibiliMapper.selectAll(); }
    @Override
    public int selectNumBySql(String sql){
        return bilibiliMapper.selectNumBySql(sql);
    }
}
