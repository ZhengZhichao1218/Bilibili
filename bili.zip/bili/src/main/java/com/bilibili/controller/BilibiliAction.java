package com.bilibili.controller;


import com.bilibili.bean.Point;
import com.bilibili.service.BilibiliService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;
import java.util.*;

@RestController
@RequestMapping("/sport")
public class BilibiliAction {
    @Resource
    private BilibiliService bilibiliService;

    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public Map test() {//前端获取的数据在这里 Integer允许空
        Map map = new HashMap();
        List<Point> list = bilibiliService.selectAll();
        map.put("list",list);
        //map.put("bfl",get_bfl());
        //map.put("response", getClassfication());
        //System.out.println(getClassfication());

        return map;
    }
    public Integer[] get_bfl(){
        Integer bfl[]={};
        List<Point> list = bilibiliService.selectAll();
        for (int i=0;i<100;i++){
            bfl[i]=list.get(i).getBfl();
            //System.out.println(bfl[i]);
        }
        return bfl;
    }

}
